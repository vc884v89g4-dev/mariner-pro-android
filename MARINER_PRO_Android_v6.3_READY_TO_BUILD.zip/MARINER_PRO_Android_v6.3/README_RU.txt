MARINER PRO Android v6.3

Это Android WebView-обёртка для текущего MARINER PRO v6.3 BIG REBUILD.
Приложение загружает index.html локально из assets и работает офлайн.

Автоматическая сборка:
1. Загрузить содержимое папки в GitHub repository.
2. GitHub Actions -> Build APK -> Run workflow.
3. Скачать artifact MARINER-PRO-v6.3-APK.
4. Внутри будет app-debug.apk, который можно установить на Android.

Package: com.marinerpro.app
Min Android: 7.0 (API 24)
Target SDK: 35
Version: 6.3
